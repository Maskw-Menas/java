package service;

import model.Car;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Класс TaxiPark представляет таксопарк, содержащий легковые автомобили.
 */
public class TaxiPark {
    private List<Car> cars; // Список автомобилей в таксопарке

    /**
     * Конструктор для создания таксопарка.
     */
    public TaxiPark() {
        cars = new ArrayList<>();
    }

    /**
     * Добавить автомобиль в таксопарк.
     *
     * @param car Автомобиль, который нужно добавить
     */
    public void addCar(Car car) {
        cars.add(car);
    }

    /**
     * Получить список всех автомобилей в таксопарке.
     *
     * @return Список автомобилей
     */
    public List<Car> getCars() {
        return cars;
    }

    /**
     * Рассчитать общую стоимость всех автомобилей в таксопарке.
     *
     * @return Общая стоимость
     */
    public double getTotalPrice() {
        return cars.stream().mapToDouble(Car::getPrice).sum();
    }

    /**
     * Отсортировать автомобили по расходу топлива.
     */
    public void sortByFuelConsumption() {
        cars.sort(Comparator.comparingDouble(Car::getFuelConsumption));
    }

    /**
     * Найти автомобили, соответствующие заданному диапазону скорости.
     *
     * @param min Минимальная скорость
     * @param max Максимальная скорость
     * @return Список автомобилей, соответствующих критериям
     */
    public List<Car> findCarsBySpeedRange(double min, double max) {
        List<Car> result = new ArrayList<>();
        for (Car car : cars) {
            if (car.getMaxSpeed() >= min && car.getMaxSpeed() <= max) {
                result.add(car);
            }
        }
        return result;
    }
}