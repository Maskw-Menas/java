package model;

/**
 * Класс Car представляет легковой автомобиль с основными характеристиками.
 */
public class Car {
    private String brand;             // Марка автомобиля
    private String model;             // Модель автомобиля
    private double price;             // Цена автомобиля
    private double fuelConsumption;   // Расход топлива (л/100 км)
    private double maxSpeed;          // Максимальная скорость (км/ч)

    /**
     * Конструктор для создания автомобиля.
     *
     * @param brand            Марка автомобиля
     * @param model            Модель автомобиля
     * @param price            Цена автомобиля
     * @param fuelConsumption  Расход топлива (л/100 км)
     * @param maxSpeed         Максимальная скорость (км/ч)
     */
    public Car(String brand, String model, double price, double fuelConsumption, double maxSpeed) {
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.fuelConsumption = fuelConsumption;
        this.maxSpeed = maxSpeed;
    }

    // Геттеры для доступа к полям
    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getPrice() {
        return price;
    }

    public double getFuelConsumption() {
        return fuelConsumption;
    }

    public double getMaxSpeed() {
        return maxSpeed;
    }

    /**
     * Переопределение метода toString() для удобного вывода информации об автомобиле.
     *
     * @return Строковое представление объекта Car
     */
    @Override
    public String toString() {
        return "Car {" +
                "Brand='" + brand + '\'' +
                ", Model='" + model + '\'' +
                ", Price=" + price +
                ", Fuel Consumption=" + fuelConsumption + " l/100km" +
                ", Max Speed=" + maxSpeed + " km/h" +
                '}';
    }
}