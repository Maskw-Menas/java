package app;

import model.Car;
import service.TaxiPark;

import java.util.List;
import java.util.Scanner;

public class TaxiParkApp {
    public static void main(String[] args) {
        TaxiPark taxiPark = new TaxiPark();
        Scanner scanner = new Scanner(System.in);

        // Предопределенные данные
        List<String> availableBrands = List.of("Toyota", "BMW", "Mercedes");
        List<String> availableModels = List.of("Corolla", "X5", "E-Class");
        List<Double> availablePrices = List.of(20000.0, 50000.0, 40000.0); // Цена
        List<Double> availableFuelConsumptions = List.of(6.0, 8.5, 7.2); // Расход топлива
        List<Double> availableSpeeds = List.of(180.0, 240.0, 220.0); // Максимальная скорость

        // Инициализация таксопарка
        for (int i = 0; i < availableBrands.size(); i++) {
            taxiPark.addCar(new Car(availableBrands.get(i), availableModels.get(i), availablePrices.get(i), availableFuelConsumptions.get(i), availableSpeeds.get(i)));
        }

        while (true) {
            System.out.println("\nМеню:");
            System.out.println("1. Добавить автомобиль");
            System.out.println("2. Показать все автомобили");
            System.out.println("3. Рассчитать общую стоимость таксопарка");
            System.out.println("4. Отсортировать автомобили по расходу топлива");
            System.out.println("5. Найти автомобили по диапазону скорости");
            System.out.println("6. Выйти");
            System.out.print("Выберите действие: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Очистка ввода

            switch (choice) {
                case 1:
                    // Добавление автомобиля
                    System.out.println("Выберите марку:");
                    for (int i = 0; i < availableBrands.size(); i++) {
                        System.out.printf("%d. %s%n", i + 1, availableBrands.get(i));
                    }
                    int brandChoice = scanner.nextInt() - 1;
                    scanner.nextLine(); // Очистка ввода

                    String brand = availableBrands.get(brandChoice);
                    String model = availableModels.get(brandChoice);
                    double price = availablePrices.get(brandChoice);
                    double fuelConsumption = availableFuelConsumptions.get(brandChoice);
                    double speed = availableSpeeds.get(brandChoice);

                    taxiPark.addCar(new Car(brand, model, price, fuelConsumption, speed));
                    System.out.println("Автомобиль добавлен!");
                    break;

                case 2:
                    System.out.println("Список автомобилей:");
                    taxiPark.getCars().forEach(System.out::println);
                    break;

                case 3:
                    System.out.println("Общая стоимость таксопарка: " + taxiPark.getTotalPrice());
                    break;

                case 4:
                    taxiPark.sortByFuelConsumption();
                    System.out.println("Автомобили отсортированы по расходу топлива:");
                    taxiPark.getCars().forEach(System.out::println);
                    break;

                case 5:
                    System.out.print("Введите минимальную скорость: ");
                    double minSpeed = scanner.nextDouble();
                    System.out.print("Введите максимальную скорость: ");
                    double maxSpeed = scanner.nextDouble();

                    List<Car> foundCars = taxiPark.findCarsBySpeedRange(minSpeed, maxSpeed);
                    if (foundCars.isEmpty()) {
                        System.out.println("Нет автомобилей, соответствующих заданным параметрам.");
                    } else {
                        System.out.println("Найденные автомобили:");
                        foundCars.forEach(System.out::println);
                    }
                    break;

                case 6:
                    System.out.println("Выход из программы.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Неверный выбор. Попробуйте снова.");
            }
        }
    }
}