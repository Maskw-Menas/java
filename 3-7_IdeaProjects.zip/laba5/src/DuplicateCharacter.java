import java.util.Scanner;

public class DuplicateCharacter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        String input = scanner.nextLine(); // Считываем строку
        scanner.close(); // Закрываем сканер

        char duplicate = findDuplicateCharacter(input); // Находим дубликат
        System.out.println(duplicate); // Выводим найденную букву
    }

    // Функция для поиска дублирующегося символа
    public static char findDuplicateCharacter(String str) {
        for (int i = 0; i < str.length(); i++) { // Проходим по каждому символу строки
            char currentChar = str.charAt(i); // Получаем текущий символ
            for (int j = 0; j < str.length(); j++) { // Сравниваем с остальными символами
                if (i != j && currentChar == str.charAt(j)) { // Если символ найден второй раз
                    return currentChar; // Возвращаем этот символ
                }
            }
        }
        // Если символ не найден, хотя по условию задачи (не должна достигаться эта строка)
        return '\0'; // Возвращаем пустой символ (не должен достигать этого кода)
    }
}