import java.util.Scanner;

public class CheckDigit {

    // Функция, определяющая, является ли символ цифрой
    public static boolean IsDigit(char c) {
        // Проверяем, находится ли символ в диапазоне '0' - '9'
        return c >= '0' && c <= '9';
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        char c = scanner.next().charAt(0); // Считываем символ c
        scanner.close(); // Закрываем сканер

        // Вызываем функцию и выводим результат
        if (IsDigit(c)) {
            System.out.println("yes"); // Если символ является цифрой, выводим "yes"
        } else {
            System.out.println("no"); // В противном случае выводим "no"
        }
    }
}