import java.util.Scanner;

public class LongestWord {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        String input = scanner.nextLine(); // Считываем строку пользователя
        scanner.close(); // Закрываем сканер

        // Удаляем лишние пробелы и разбиваем строку на слова
        String[] words = input.trim().split("\\s+");

        String longestWord = ""; // Переменная для хранения самого длинного слова
        int maxLength = 0; // Переменная для хранения длины самого длинного слова

        // Проходим по всем словам и ищем самое длинное
        for (String word : words) {
            if (word.length() > maxLength) {
                maxLength = word.length();
                longestWord = word; // Обновляем самое длинное слово
            }
        }

        // Выводим результат в формате, требуемом
        System.out.println(longestWord);
        System.out.println(maxLength);
    }
}