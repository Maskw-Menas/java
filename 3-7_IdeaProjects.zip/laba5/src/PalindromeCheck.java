import java.util.Scanner;

public class PalindromeCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        String input = scanner.nextLine(); // Считываем строку
        scanner.close(); // Закрываем сканер

        if (isPalindrome(input)) { // Проверяем, является ли строка палиндромом
            System.out.println("yes"); // Выводим "yes", если палиндром
        } else {
            System.out.println("no"); // Выводим "no", если не палиндром
        }
    }

    // Функция для проверки, является ли слово палиндромом
    public static boolean isPalindrome(String str) {
        String reversedStr = new StringBuilder(str).reverse().toString(); // Реверсируем строку
        return str.equals(reversedStr); // Сравниваем оригинальную и реверсированную строки
    }
}