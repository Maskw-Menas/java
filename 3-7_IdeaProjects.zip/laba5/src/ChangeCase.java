import java.util.Scanner;

public class ChangeCase {

    // Функция для изменения регистра символа
    public static char ChangeCharCase(char c) {
        if (Character.isLowerCase(c)) { // Если символ строчный
            return Character.toUpperCase(c); // Возвращаем заглавный
        } else if (Character.isUpperCase(c)) { // Если символ заглавный
            return Character.toLowerCase(c); // Возвращаем строчный
        } else { // Если не латинская буква, возвращаем символ как есть
            return c;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        char c = scanner.next().charAt(0); // Считываем символ C
        scanner.close(); // Закрываем сканер
        char result = ChangeCharCase(c); // Меняем регистр символа
        System.out.println(result); // Выводим результат
    }
}