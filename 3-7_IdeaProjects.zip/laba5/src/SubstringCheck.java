import java.util.Scanner;

public class SubstringCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        String str1 = scanner.nextLine(); // Считываем первую строку
        String str2 = scanner.nextLine(); // Считываем вторую строку
        scanner.close(); // Закрываем сканер

        // Проверяем, является ли str1 подстрокой str2
        if (str2.contains(str1)) {
            System.out.println("yes"); // Первая строка является подстрокой второй
        } else {
            System.out.println("no"); // Первая строка не является подстрокой второй
        }
    }
}