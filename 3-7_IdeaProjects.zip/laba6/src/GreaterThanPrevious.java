import java.util.Scanner;

public class GreaterThanPrevious {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        int N = scanner.nextInt(); // Считываем количество элементов

        // Проверяем условие на минимально допустимое количество элементов
        if (N < 1 || N > 10000) {
            System.out.println("Invalid input size.");
            return;
        }

        int[] array = new int[N]; // Создаем массив указанного размера

        // Считываем элементы массива
        for (int i = 0; i < N; i++) {
            array[i] = scanner.nextInt(); // Считываем очередное число
        }
        scanner.close(); // Закрываем сканер

        int count = 0; // Переменная для подсчета элементов

        // Проходим по массиву и проверяем, больше ли текущий элемент предыдущего
        for (int i = 1; i < N; i++) { // начинаем с 1, чтобы сравнивать с предыдущим
            if (array[i] > array[i - 1]) { // Если текущий элемент больше предыдущего
                count++; // Увеличиваем счетчик
            }
        }

        // Выводим количество найденных элементов
        System.out.println(count);
    }
}