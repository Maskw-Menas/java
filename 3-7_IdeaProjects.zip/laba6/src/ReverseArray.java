import java.util.Scanner;

public class ReverseArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        int N = scanner.nextInt(); // Считываем количество элементов
        int[] array = new int[N]; // Создаем массив указанного размера

        // Считываем элементы массива
        for (int i = 0; i < N; i++) {
            array[i] = scanner.nextInt(); // Считываем очередное число
        }
        scanner.close(); // Закрываем сканер

        // Переставляем элементы массива в обратном порядке
        for (int i = 0; i < N / 2; i++) {
            int temp = array[i]; // Сохраняем текущий элемент
            array[i] = array[N - 1 - i]; // Меняем элемент с его парным с другой стороны
            array[N - 1 - i] = temp; // Восстанавливаем сохраненный элемент
        }
        // Выводим элементы массива в обратном порядке
        for (int i = 0; i < N; i++) {
            System.out.print(array[i]); // Печатаем элемент
            if (i < N - 1) System.out.print(" "); // Пробел между числами
        }
    }
}