import java.util.Scanner;

public class SameSignNeighbors {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        int N = scanner.nextInt(); // Считываем количество элементов
        int[] array = new int[N]; // Создаем массив указанного размера

        // Считываем элементы массива
        for (int i = 0; i < N; i++) {
            array[i] = scanner.nextInt(); // Считываем очередное число
        }
        scanner.close(); // Закрываем сканер

        // Проверяем пары соседних элементов на одинаковый знак
        for (int i = 1; i < N; i++) { // начинаем с 1, чтобы сравнивать с предыдущим
            if ((array[i] > 0 && array[i - 1] > 0) || (array[i] < 0 && array[i - 1] < 0)) {
                System.out.println("YES"); // Пара с одинаковыми знаками найдена
                return; // Завершаем программу
            }
        }

        // Если не нашли пар с одинаковыми знаками, выводим NO
        System.out.println("NO");
    }
}