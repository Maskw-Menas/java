import java.util.Scanner;

public class SwapAdjacentElements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        int N = scanner.nextInt(); // Считываем количество элементов
        int[] array = new int[N]; // Создаем массив указанного размера

        // Считываем элементы массива
        for (int i = 0; i < N; i++) {
            array[i] = scanner.nextInt(); // Считываем очередное число
        }
        scanner.close(); // Закрываем сканер

        // Переставляем соседние элементы
        for (int i = 0; i < N - 1; i += 2) { // Проходим по массиву с шагом 2
            int temp = array[i]; // Сохраняем текущий элемент
            array[i] = array[i + 1]; // Меняем текущий элемент с последующим
            array[i + 1] = temp; // Восстанавливаем сохраненный элемент
        }

        // Выводим элементы массива после перестановки
        for (int i = 0; i < N; i++) {
            System.out.print(array[i]); // Печатаем элемент
            if (i < N - 1) {
                System.out.print(" "); // Пробел между числами
            }
        }
    }
}