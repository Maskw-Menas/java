import java.util.Scanner;

public class EvenElements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        int N = scanner.nextInt(); // Считываем количество элементов
        int[] array = new int[N]; // Создаем массив указанного размера

        // Считываем элементы массива
        for (int i = 0; i < N; i++) {
            array[i] = scanner.nextInt();
        }
        scanner.close(); // Закрываем сканер

        // Переменная для хранения результата
        StringBuilder result = new StringBuilder();

        // Проходим по массиву и проверяем на четность
        for (int num : array) {
            if (num % 2 == 0) { // Если число четное
                result.append(num).append(" "); // Добавляем его в результат
            }
        }

        // Выводим результат
        System.out.println(result.toString().trim()); // Удаляем лишний пробел в конце
    }
}
