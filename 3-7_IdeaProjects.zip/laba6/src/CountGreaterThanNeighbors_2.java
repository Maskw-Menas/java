import java.util.Scanner;

public class CountGreaterThanNeighbors_2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        int N = scanner.nextInt(); // Считываем количество элементов
        int[] array = new int[N]; // Создаем массив указанного размера

        // Считываем элементы массива
        for (int i = 0; i < N; i++) {
            array[i] = scanner.nextInt(); // Считываем очередное число
        }
        scanner.close(); // Закрываем сканер

        int count = 0; // Переменная для подсчета таких элементов
        // Проверяем каждый элемент, начиная со второго и до предпоследнего
        for (int i = 1; i < N - 1; i++) {
            if (array[i] > array[i - 1] && array[i] > array[i + 1]) {
                count++; // Увеличиваем счетчик, если элемент больше обоих соседей
            }
        }

        // Выводим количество таких элементов
        System.out.println(count);
    }
}