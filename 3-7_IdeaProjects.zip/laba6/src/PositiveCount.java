import java.util.Scanner;

public class PositiveCount {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        int N = scanner.nextInt(); // Считываем количество элементов
        int countPositive = 0; // Переменная для подсчета положительных элементов

        // Считываем элементы массива и подсчитываем положительные числа
        for (int i = 0; i < N; i++) {
            int number = scanner.nextInt(); // Считываем очередное число
            if (number > 0) { // Проверяем, является ли число положительным
                countPositive++; // Увеличиваем счетчик положительных чисел
            }
        }

        scanner.close(); // Закрываем сканер

        // Выводим количество положительных элементов
        System.out.println(countPositive);
    }
}