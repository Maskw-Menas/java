import java.util.Scanner;

public class Factorial {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Считываем значение N
        int N = scanner.nextInt();

        // Проверяем, что N не превышает 12
        if (N < 1 || N > 12) {
            System.out.println("Значение N должно быть в диапазоне от 1 до 12.");
            return;
        }

        long factorial = 1; // Используем long для хранения результата

        // Вычисляем факториал
        for (int i = 1; i <= N; i++) {
            factorial *= i; // Умножаем на текущее число
        }

        // Выводим результат
        System.out.println(factorial);

        scanner.close(); // Закрываем сканер
    }
}