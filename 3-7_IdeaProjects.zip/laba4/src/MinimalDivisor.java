import java.util.Scanner;

public class MinimalDivisor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        int N = scanner.nextInt(); // Считываем число N
        scanner.close(); // Закрываем сканер

        for (int i = 2; i <= Math.sqrt(N); i++) {
            if (N % i == 0) { // Проверяем, является ли i делителем N
                System.out.println(i); // Если да, выводим его
                return; // Уходим из программы после нахождения первого делителя
            }
        }

        System.out.println(N); // Если делителей не найдено, выводим N (число является простым)
    }
}