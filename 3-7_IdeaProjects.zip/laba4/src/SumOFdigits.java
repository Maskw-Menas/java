import java.util.Scanner;

public class SumOFdigits {

    // Функция для вычисления суммы цифр числа
    public static int SumOfDigits(int n) {
        int sum = 0; // Инициализация суммы
        while (n > 0) {
            sum += n % 10; // Добавляем последнюю цифру к сумме
            n /= 10;       // Убираем последнюю цифру
        }
        return sum; // Возврат результата
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        int N = scanner.nextInt(); // Считываем натуральное число N
        System.out.println(SumOfDigits(N)); // Выводим сумму цифр
        scanner.close(); // Закрываем сканер
    }
}