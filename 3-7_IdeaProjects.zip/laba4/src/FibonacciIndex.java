import java.util.Scanner;

public class FibonacciIndex {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int A = scanner.nextInt(); // Считываем число A
        scanner.close();

        if (A <= 1) {
            System.out.println(-1); // Если A ≤ 1, выводим -1
            return;
        }

        int a = 1; // Первое число Фибоначчи φ1
        int b = 1; // Второе число Фибоначчи φ2
        int index = 2; // Начинаем считать с индекса 2

        while (b < A) { // Пока b меньше A
            int temp = b;
            b = a + b; // Переходим к следующему числу Фибоначчи
            a = temp;
            index++; // Увеличиваем индекс
        }

        // Проверяем, нашли ли мы A в качестве числа Фибоначчи
        if (b == A) {
            System.out.println(index); // Если нашли, выводим индекс
        } else {
            System.out.println(-1); // Если не нашли, выводим -1
        }
    }
}