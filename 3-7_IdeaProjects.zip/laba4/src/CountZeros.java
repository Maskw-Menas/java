import java.util.Scanner;

public class CountZeros {

    // Функция для подсчета количества нулей в числе
    public static int CountZeros(int n) {
        int count = 0; // Инициализация счетчика нулей
        while (n > 0) {
            if (n % 10 == 0) { // Проверяем, является ли последняя цифра нулем
                count++; // Увеличиваем счетчик
            }
            n /= 10; // Убираем последнюю цифру
        }
        return count; // Возвращаем общее количество нулей
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Создаем сканер для ввода
        int N = scanner.nextInt(); // Считываем натуральное число N
        System.out.println(CountZeros(N)); // Выводим количество нулей
        scanner.close(); // Закрываем сканер
    }
}