import java.util.Scanner;

public class CountPalindromes {

    // Функция для проверки, является ли число палиндромом
    public static boolean isPalindrome(int n) {
        String str = Integer.toString(n);
        int len = str.length();

        for (int i = 0; i < len / 2; i++) {
            if (str.charAt(i) != str.charAt(len - 1 - i)) {
                return false; // Если символы не равны, то это не палиндром
            }
        }
        return true; // Если все символы совпали, то это палиндром
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int K = scanner.nextInt(); // Считываем число K
        int count = 0;

        // Проходим все числа от 1 до K и считаем палиндромы
        for (int i = 1; i <= K; i++) {
            if (isPalindrome(i)) {
                count++; // Увеличиваем счетчик, если число палиндром
            }
        }

        System.out.println(count); // Выводим количество палиндромов
        scanner.close(); // Закрываем сканер
    }
}