import java.util.Scanner;

public class SumOFsquares {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Считываем значение n
        int n = scanner.nextInt();

        // Проверяем, что n не превышает 100
        if (n < 1 || n > 100) {
            System.out.println("Значение n должно быть в диапазоне от 1 до 100.");
            return;
        }

        int sum = 0;

        // Вычисляем сумму квадратов
        for (int i = 1; i <= n; i++) {
            sum += i * i; // Добавляем квадрат текущего числа i к сумме
        }

        // Выводим результат
        System.out.println(sum);

        scanner.close(); // Закрываем сканер
    }
}