import java.util.Scanner;

public class RomanNumerals {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Считываем число X
        int X = scanner.nextInt();

        // Проверка на допустимость ввода
        if (X < 1 || X > 100) {
            System.out.println("Значение должно быть в пределах от 1 до 100.");
            return; // Завершаем программу, если значение вне диапазона
        }

        // Массивы римских символов и их соответствующих значений
        String[] romanNumerals = {
                "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"
        };
        int[] values = {
                100, 90, 50, 40, 10, 9, 5, 4, 1
        };

        StringBuilder result = new StringBuilder(); // Для хранения результата

        // Преобразуем десятичное число в римское
        for (int i = 0; i < values.length; i++) {
            while (X >= values[i]) {
                result.append(romanNumerals[i]); // Добавляем римский символ
                X -= values[i]; // Уменьшаем число X
            }
        }

        // Выводим результат
        System.out.println(result.toString());
        scanner.close(); // Закрываем сканер
    }
}