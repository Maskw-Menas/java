import java.util.Scanner;public class triangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ввод сторон треугольника
        int a = scanner.nextInt();
        int b = scanner.nextInt();
        int c = scanner.nextInt();

        // Проверка на существование треугольника
        if (a + b <= c || a + c <= b || b + c <= a) {
            System.out.println("impossible");
        } else {
            // Проверка на тип треугольника
            int a2 = a * a;
            int b2 = b * b;
            int c2 = c * c;

            if (a2 + b2 == c2 || a2 + c2 == b2 || b2 + c2 == a2) {
                System.out.println("right");
            } else if (a2 + b2 < c2 || a2 + c2 < b2 || b2 + c2 < a2) {
                System.out.println("obtuse");
            } else {
                System.out.println("acute");
            }
        }

        scanner.close();
    }
}