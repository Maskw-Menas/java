import java.util.Scanner;

public class cow {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt(); // Считываем число n

        String word;
        if (n % 10 == 1 && n % 100 != 11) {
            word = "korova"; // 1 корова
        } else if (n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20)) {
            word = "korovy"; // 2, 3, 4 коровы
        } else {
            word = "korov"; // 0, 5-9, 11-14 и т.д.
        }

        // Выводим результат
        System.out.println(n + " " + word);
        scanner.close();
    }
}