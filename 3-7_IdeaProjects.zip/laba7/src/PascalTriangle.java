import java.util.Scanner;

public class PascalTriangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Считываем размеры массива
        int n = scanner.nextInt();
        int m = scanner.nextInt();

        // Создаем двумерный массив размером n x m
        int[][] array = new int[n][m];

        // Заполняем первый ряд и первый столбец единицами
        for (int i = 0; i < n; i++) {
            array[i][0] = 1; // Первая колонка
        }
        for (int j = 0; j < m; j++) {
            array[0][j] = 1; // Первый ряд
        }

        // Заполняем остальные элементы
        for (int i = 1; i < n; i++) {
            for (int j = 1; j < m; j++) {
                array[i][j] = array[i - 1][j] + array[i][j - 1]; // Сумма сверху и слева
            }
        }

        // Выводим массив
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                System.out.print(array[i][j]); // Печатаем элемент
                if (j < m - 1) {
                    System.out.print(" "); // Пробел между числами
                }
            }
            System.out.println(); // Переход на новую строку после каждой строки массива
        }

        scanner.close(); // Закрываем сканер
    }
}