import java.util.Scanner;

public class SecondaryDiagonal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt(); // Считываем размерность массива

        // Создаем двумерный массив
        int[][] array = new int[n][n];

        // Заполняем массив в соответствии с правилами
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (j + i == n - 1) {
                    array[i][j] = 1; // Значение на побочной диагонали
                } else if (j + i < n - 1) {
                    array[i][j] = 0; // Значение выше побочной диагонали
                } else {
                    array[i][j] = 2; // Значение ниже побочной диагонали
                }
            }
        }

        // Выводим полученный массив
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(array[i][j]); // Печатаем элемент
                if (j < n - 1) {
                    System.out.print(" "); // Пробел между числами
                }
            }
            System.out.println(); // Переход на новую строку после вывода строки массива
        }

        scanner.close(); // Закрываем сканер
    }
}