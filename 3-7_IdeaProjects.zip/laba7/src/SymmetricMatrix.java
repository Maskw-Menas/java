import java.util.Scanner;

public class SymmetricMatrix {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Считываем размер матрицы
        int n = scanner.nextInt();
        int[][] matrix = new int[n][n];

        // Считываем элементы матрицы
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matrix[i][j] = scanner.nextInt(); // Считываем элемент
            }
        }

        // Проверяем симметричность
        boolean isSymmetric = true;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < i; j++) { // Сравниваем только ниже главной диагонали
                if (matrix[i][j] != matrix[j][i]) {
                    isSymmetric = false; // Найдена разница
                    break;
                }
            }
            if (!isSymmetric) {
                break; // Прекращаем, если найдено несоответствие
            }
        }

        // Вывод результата
        if (isSymmetric) {
            System.out.println("yes");
        } else {
            System.out.println("no");
        }

        scanner.close(); // Закрываем сканер
    }
}